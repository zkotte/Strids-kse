// Stridsøkse – offline: appen hentes fra nettet, når der er net (højst 3,5 sek.), ellers fra telefonen
const V = "stridsokse-v111";
const CORE = ["./", "index.html", "spil.html", "lore.html", "manifest.webmanifest", "icon.svg", "icon-192.png", "icon-512.png", "icon-maskable-512.png", "apple-touch-icon.png"];
const EXT = /(^|\.)fonts\.(googleapis|gstatic)\.com$|(^|\.)cdnjs\.cloudflare\.com$|(^|\.)cdn\.jsdelivr\.net$/;
self.addEventListener("install", e => { e.waitUntil(caches.open(V).then(c => c.addAll(CORE)).then(() => self.skipWaiting())); });
self.addEventListener("activate", e => { e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k.startsWith("stridsokse-") && k !== V).map(k => caches.delete(k)))).then(() => self.clients.claim())); });
self.addEventListener("fetch", e => {
  const r = e.request; if (r.method !== "GET") return;
  const u = new URL(r.url);
  if ((r.mode === "navigate" || r.destination === "iframe") && u.origin === location.origin) {
    const key = /spil\.html$/.test(u.pathname) ? "spil.html" : /lore\.html$/.test(u.pathname) ? "lore.html" : "index.html";
    e.respondWith((async () => {
      const c = await caches.open(V);
      const net = fetch(r).then(res => { if (res && res.ok) c.put(key, res.clone()); return res; });
      const slow = new Promise(res => setTimeout(res, 3500, null));
      try { const res = await Promise.race([net, slow]); if (res && res.ok) return res; } catch (x) {}
      const hit = await c.match(key);
      if (hit) return hit;
      return net;
    })());
    return;
  }
  if (u.origin === location.origin || EXT.test(u.hostname)) {
    e.respondWith(caches.match(r).then(hit => hit || fetch(r).then(res => {
      if (res && (res.ok || res.type === "opaque")) { const cl = res.clone(); caches.open(V).then(c => c.put(r, cl)); }
      return res;
    })));
  }
});
